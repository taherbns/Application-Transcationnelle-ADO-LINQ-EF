﻿

function incrementQuantity(productId) {
    var quantityInput = document.getElementById('quantity_' + productId);
    var paypalQuantityInput = document.getElementById('paypal_quantity_' + productId);
    quantityInput.value++;
    paypalQuantityInput.value = quantityInput.value;
}

function decrementQuantity(productId) {
    var quantityInput = document.getElementById('quantity_' + productId);
    var paypalQuantityInput = document.getElementById('paypal_quantity_' + productId);
    if (quantityInput.value > 1) {
        quantityInput.value--;
        paypalQuantityInput.value = quantityInput.value;
    }
}
