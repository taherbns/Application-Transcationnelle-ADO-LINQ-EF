﻿CREATE TABLE [dbo].[Etudiant] (
    [Id]         INT        NOT NULL IDENTITY,
    [nom]        NCHAR (50) NULL,
    [prenom ]    NCHAR (50) NULL,
    [niveauEduc] NCHAR (50) NULL,
    [courriel]   NCHAR (50) NULL,
    [idLogin]    INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

