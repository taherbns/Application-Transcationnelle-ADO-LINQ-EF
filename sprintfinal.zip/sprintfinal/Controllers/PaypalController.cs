﻿using laboratoire1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace laboratoire1.Controllers
{
    public class paypalController : Controller
    {
        // GET: paypal


        public ActionResult ajouterAuPanier()
        {
            List<produit> produits = new List<produit>()
        {
            new produit
            {
                id = 1,
                nom = "E-learning",
                description = "livre pour vous apprendre à coder",
                quantite = 1,
                prix = 30.28,
                shipping = 1.5
            },
            new produit
            {
                id = 2,
                nom = "E-book Java",
                description = "livre pour vous apprendre à coder en Java",
                quantite = 1,
                prix = 30.28,
                shipping = 4.5
            },
            new produit
            {
                id = 3,
                nom = "Apprentissage Python",
                description = "guide pour maîtriser la programmation Python",
                quantite = 1,
                prix = 25.50,
                shipping = 2.0
            },
            new produit
            {
                id = 4,
                nom = "Cours de développement Web",
                description = "ensemble complet pour devenir un développeur web",
                quantite = 1,
                prix = 40.75,
                shipping = 3.25
            },
            new produit
            {
                id = 5,
                nom = "Applications mobiles",
                description = "livre pour créer des applications mobiles",
                quantite = 1,
                prix = 28.90,
                shipping = 2.75
            },
            new produit
            {
                id = 6,
                nom = "Data Science avancée",
                description = "guide pour maîtriser la science des données",
                quantite = 1,
                prix = 35.20,
                shipping = 3.0
            }
        };


            return View("payer", produits);

        }

    }
}