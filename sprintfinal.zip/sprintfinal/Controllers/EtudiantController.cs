﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Web.Mvc;
using laboratoire1.Models;
using System.Runtime.Remoting.Messaging;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using System.EnterpriseServices;

namespace laboratoire1.Controllers
{
   
    public class EtudiantController : Controller
    {
        private etudiantDbContext db;
        
        // GET: Etudiant
        public ActionResult inscription()
        {
          
                 
            return View();

        }

        [HttpPost]
        public ActionResult inscription(string nom, string prenom, string niveauEduc, string courriel)
        {
            if (ModelState.IsValid)
            {
                // verfier si l'e-mail existe déja dans la bd
                bool emailExists = false;

                SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\App_Data\\Etudiant.mdf;Integrated Security=True");

                con.Open();

                SqlCommand emailCheckCmd = new SqlCommand("SELECT * FROM Etudiant WHERE courriel = @courriel", con);
                emailCheckCmd.Parameters.AddWithValue("@courriel", courriel);

                emailExists = emailCheckCmd.ExecuteScalar() != null;


                if (emailExists)
                {
                    // L'adresse e-mail est déjà utilisée, afficher un message d'erreur
                    ViewBag.ErrorMessage = "Un étudiant est déjà inscrit avec cette adresse e-mail.";
                    return RedirectToAction("erreur");
                }
                string idLogin = generateIdLogin(nom, prenom);
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\App_Data\\Etudiant.mdf;Integrated Security=True");

                conn.Open();
              
                SqlCommand insertCmd = new SqlCommand("INSERT INTO Etudiant (nom, prenom, niveauEduc, courriel ,idLogin) " +
                    "VALUES (@nom, @prenom, @niveauEduc, @courriel,@idLogin)", conn);
                insertCmd.Parameters.AddWithValue("@nom", nom);
                insertCmd.Parameters.AddWithValue("@prenom", prenom);
                insertCmd.Parameters.AddWithValue("@niveauEduc", niveauEduc);
                insertCmd.Parameters.AddWithValue("@courriel", courriel);
                insertCmd.Parameters.AddWithValue("@idLogin", idLogin);


                insertCmd.ExecuteNonQuery();

                string user = generateUser(nom,prenom);
                string pwd = generatepwd(nom);
                 
           SqlCommand insertCmdlogin =    new SqlCommand("INSERT INTO login ([user], pwd, status ,idLogin) " +
                   "VALUES (@user, @pwd, @status,@idLogin)", conn);
                insertCmdlogin.Parameters.AddWithValue("@idLogin", idLogin);
                insertCmdlogin.Parameters.AddWithValue("@user", user);
                insertCmdlogin.Parameters.AddWithValue("@pwd", pwd);
                insertCmdlogin.Parameters.AddWithValue("@status", 0);
                insertCmdlogin.ExecuteNonQuery();

                Email email = new Email  { To = courriel ,Subject = "information de login ",Message = "votre user est : "  +  user  +  " votre password est : "  +  pwd  };
                if (SendMail(email))
                {
                    return RedirectToAction("confirmation");
                }
                else
                {
                    // Gérer l'erreur d'envoi d'e-mail
                    ViewBag.ErrorMessage = "Une erreur s'est produite lors de l'envoi de l'e-mail.";
                    return RedirectToAction("erreur");
                }

             
            }

            return View();
        }
        public ActionResult confirmation()
        {
            return View("confirmation");
        }
        public ActionResult erreur()
        {
            return View("erreur");
        }
        public ActionResult loginSuccess()
        {
            return View("loginSuccess");
        }
        public ActionResult login()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult login(string user, string Newpwd)
        {
            SqlConnection connect = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\App_Data\\Etudiant.mdf;Integrated Security=True");
            connect.Open();

            SqlCommand updateCmdLogin = new SqlCommand("UPDATE login SET pwd = @Newpwd, status = 1 WHERE [user] = @user", connect);
            updateCmdLogin.Parameters.AddWithValue("@Newpwd", Newpwd);
            updateCmdLogin.Parameters.AddWithValue("@user", user);

            updateCmdLogin.ExecuteNonQuery();

            return View("loginSuccess");
        }

        public ActionResult loginEtudiant()
        {
            return View();
        }
        [HttpPost]
        public ActionResult loginEtudiant(string user , string pwd)
        {
            SqlConnection connect = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\App_Data\\Etudiant.mdf;Integrated Security=True");
            connect.Open();
            SqlCommand cmd = new SqlCommand("SELECT  [user], pwd FROM login WHERE [user] = @user AND pwd = @pwd", connect);


            cmd.Parameters.AddWithValue("@user", user);
            cmd.Parameters.AddWithValue("@pwd", pwd);

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                
                return View("loginSuccess");
            }
            else
            {
                // Les informations  sont pas correcte
                ViewBag.ErrorMessage = "Informations de connexion incorrectes.";
                return View("fausseInfo");
            }
        }


        public ActionResult cours()
        {
            List<cours> listeCours = new List<cours>();

            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\tbns1\\Desktop\\sprint\\sprintfs\\App_Data\\Etudiant.mdf;Integrated Security=True");
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * from Cours", conn);
                
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cours courEtudiant = new cours
                    { 
                        titre = reader["titre"].ToString(),
                        numCours = reader["numCours"].ToString(),
                        niveauEduc = reader["niveauEduc"].ToString(),
                        video = reader["video"].ToString(),
                        description = reader["description"].ToString(),
                        notes = reader.GetInt32(reader.GetOrdinal("notes")),
                        labo = reader["exercices"].ToString(),
                        exercices = reader["exercices"].ToString(),
                         solutionnaire = reader["solutionnaire"].ToString()

                    };
                    listeCours.Add(courEtudiant);
                }
            }

            return View(listeCours);
        }
        [HttpPost]
        public ActionResult InscrireCours(int idCours)
        {
            int idetudiant = ViewBag.idetudiant;         
                using (var db = new etudiantDbContext()) 
            {
                inscritCours inscription = new inscritCours { idCour = idCours, idEtudiant = idetudiant };
               

                db.inscritcour.Add(inscription);
                db.SaveChanges();
            }

            return RedirectToAction("cours");
        }
        public ActionResult AfficheCoursInscrits(int idEtudiant)
        {
            using (var db = new etudiantDbContext()) 

            {
                var coursInscrits = (from cours in db.Cours join inscritcour in db.inscritcour on cours.id equals inscritcour.id
                                     join Etudiant in db.Etudiant on inscritcour.idEtudiant equals Etudiant.id
                                     where Etudiant.idEtudiant == idEtudiant
                                     select cours.ToList());

                return View(coursInscrits,"cours");
            }   
        }
        public ActionResult message()
        {
            return View("message");
        }

        [HttpPost]
        public ActionResult message( int IdProf ,int IdCours ,string Questions)
        {
            int idetudiant = ViewBag.idetudiant;
            using (var context = new etudiantDbContext())
            {
                var message = new Message
                {  IdProf = IdProf, IdEtudiant = idetudiant, IdCours = IdCours, Questions = Questions };
                context.message.Add(message);
                context.SaveChanges();
            }
                return RedirectToAction("cours");
        }







        public string generateIdLogin(string nom , string prenom )
        {
            return nom + prenom;
        }
        public string generateUser(string nom, string prenom)
        {
            return nom + prenom + 123;
        }
        public string generatepwd(string nom)
        {
            return nom + 010;
        }

        private bool SendMail(Email email)
        {

            string sender = System.Configuration.ConfigurationManager.AppSettings["mailSender"];
            string pw = System.Configuration.ConfigurationManager.AppSettings["mailPw"];

            try
            {
                SmtpClient smtpclient = new SmtpClient("smtp.office365.com", 587);
                smtpclient.Timeout = 3000;
                smtpclient.EnableSsl = true;
                smtpclient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpclient.UseDefaultCredentials = false;
                smtpclient.Credentials = new NetworkCredential(sender, pw);


                MailMessage mailMessage = new System.Net.Mail.MailMessage(sender, email.To, email.Subject, email.Message);
                mailMessage.BodyEncoding = System.Text.Encoding.UTF8;
                smtpclient.Send(mailMessage);

                return true;


            }
            catch (Exception ex)
            {
                return false;
            }
            

        }
    }
}