﻿using laboratoire1.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace laboratoire1.Controllers
{
    public class EnseignantController : Controller
    {
        // GET: Enseignant
        public ActionResult loginEns()
        {
            return View();
        }

        [HttpPost]
        public ActionResult loginEns(string user, string pwd)
        {
            using (var context = new enseignantDataContext("C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\Etudiant.dbml")) 
            {
                var enseignant = context.login.FirstOrDefault(e => e.user_ == user && e.pwd == pwd);

                if (enseignant != null)
                {
                    
                    return View("Acceuil");
                }
                else
                {
                   
                    ViewBag.ErrorMessage = "Informations de connexion incorrectes.";
                    return View("erreur");
                }
            }
        }

        public ActionResult listCour()
        {
            int idprof = ViewBag.idprof;
            List<cours> coursList;

            using (var  db = new enseignantDataContext("C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\Etudiant.dbml"))
            {
                coursList = db.Cours.Select(c => new cours
                {
                    id = c.Id,
                    titre = c.titre,
                    numCours = c.numCours,
                    niveauEduc = c.niveauEduc,
                    video = c.video,
                    description = c.description,
                    notes = c.notes, 
                    labo = c.labo,
                    exercices = c.exercices,
                    solutionnaire = c.solutionnaire
                }).ToList();
            }

            return View(coursList);
        }

        public ActionResult Edit(int id, HttpPostedFileBase videoFile)
        {

            int idprof = ViewBag.idprof;

            List<string> niveauxEduc = new List<string> { "primaire", "secondaire", "Dec", "aec", "baccalaureat", "universitaire" };

            using (var context = new enseignantDataContext("C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\Etudiant.dbml"))
            {
                var cours = context.Cours.FirstOrDefault(c => c.Id == id);

                if (cours != null)
                {
                    if (videoFile != null && videoFile.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(videoFile.FileName);
                        var path = Path.Combine(Server.MapPath("~/Uploads"), fileName);
                        videoFile.SaveAs(path);
                        cours.video = fileName;
                    }

                    
                    return View("Edit", cours);
                }
                else
                {
                    return HttpNotFound();
                }
            }
        }

        [HttpPost]
        public ActionResult Edit(cours cours)
        {
            if (ModelState.IsValid)
            {
                using (var context = new enseignantDataContext("C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\enseignant.dbml"))
                {
                    var cour = context.Cours.FirstOrDefault(c => c.Id == cours.id);

                    if (cour != null)
                    {
                        cour.titre = cours.titre;
                        cour.description = cours.description;
                        
                        if (string.IsNullOrEmpty(cours.video))
                        {
                            cour.video = null; 
                        }
                        else
                        {
                            cour.video = cours.video;
                        }

                        context.SubmitChanges();
                        return View("editSuccess");
                    }
                }
            }

            return View(cours);
        }



        public ActionResult Create(HttpPostedFileBase videoFile)
        {
            int idprof = ViewBag.idprof;
            List<string> niveauxeduc = new List<string> { "primaire", "secondaire", "Dec", "aec", "baccalaureat", "universitaire" };
            cours cour = new cours();
            if (videoFile != null && videoFile.ContentLength > 0)
            {

                var fileName = Path.GetFileName(videoFile.FileName);
                var path = Path.Combine(Server.MapPath("~/Uploads"), fileName);
                videoFile.SaveAs(path);
                cour.video = fileName;
            }
            
            return View(cour);
        }
        [HttpPost]
        public ActionResult Create(Cours newcours)
        { 
            using (var context = new enseignantDataContext("C:\\Users\\tbns1\\Desktop\\sprint\\sprint\\enseignant.dbml"))
            {
                context.Cours.InsertOnSubmit(newcours);
                context.SubmitChanges();
            }
            return View("CreateSuccess");
        }




        public ActionResult message()
        {
            return View("message");
        }

        [HttpPost]
        public ActionResult message(  int IdCours, string reponses)
        {
            int idprof = ViewBag.idprof;
            int idetudiant = ViewBag.idetudiant;
            using (var context = new etudiantDbContext())
            {
                var message = new Message
                { IdProf = idprof, IdEtudiant = idetudiant, IdCours = IdCours, Reponses = reponses};
                context.message.Add(message);
                context.SaveChanges();
            }
            return RedirectToAction("cours");
        }






        public ActionResult reponses()
        {
            return View("responses");
        }


        public ActionResult Acceuil()
        {
            return View("Acceuil");
        }
        public ActionResult erreur()
        {
            return View("erreur");
        }
        public ActionResult CreateSuccess()
        {
            return View("CreateSuccess");
        }
       
    }   
        
}

