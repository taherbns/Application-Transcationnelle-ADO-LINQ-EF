﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class Message
    {
        public int Id { get; set; }
        public int IdProf { get; set; }
        public int IdEtudiant { get; set; }
        public int IdCours { get; set; }
        public string Questions { get; set; }
        public string Reponses { get; set; }
    }

}