﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class carte
    {
        public string dedenteurCarte { get; set; }
        public int numCarte { get; set; }
        public int expiration { get; set; }
        public int cvc { get; set; }
    }
}