﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class enseignantDataContext : DbContext
    {
        public DbSet<cours> Cours { get; set; }
    }
}