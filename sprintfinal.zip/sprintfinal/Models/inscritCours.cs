﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class inscritCours
    {
        public int id { get; set; }
        public int idCour { get; set; }
        public int idEtudiant { get; set; }
    }
}