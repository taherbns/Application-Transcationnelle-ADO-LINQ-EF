﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class video
    {
        public int id { get; set; }
        public string titre { get; set; }
        public string url { get; set; }
        public int duree { get; set; }
    }
}