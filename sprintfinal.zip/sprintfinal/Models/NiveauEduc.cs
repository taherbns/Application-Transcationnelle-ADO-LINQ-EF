﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class NiveauEduc
    {
        public int id { get; set; }
        public String titre { get; set; }
    }
}