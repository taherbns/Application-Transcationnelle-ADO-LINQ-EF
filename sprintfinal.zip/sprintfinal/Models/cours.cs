﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class cours

    {
        public int id  { get; set; }
        public string titre { get; set; }
        public string numCours { get; set; }
        public string niveauEduc { get; set; }
        public string video { get; set; }
        public string description { get; set; }
        public int notes { get; set; }
        public string labo { get; set; }
        public string exercices { get; set; }
        public string solutionnaire { get; set; }

    }
}