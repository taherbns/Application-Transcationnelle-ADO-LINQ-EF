﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
    public class produit
    {
        public int id { get; set; }
        public string nom { get; set; }
        public string description { get; set; }
        public string url { get; set; }
        public int quantite { get; set; }
        public double prix { get; set; }
        public double shipping { get; set; }

        public void ajouterAuPanier(List<produit> panier, produit nouveauProduit)
        {
            panier.Add(nouveauProduit);
        }


        public void retirerDuPanier(List<produit> panier, int idProduit)
        {
            produit produitARetirer = panier.FirstOrDefault(p => p.id == idProduit);
            if (produitARetirer != null)
            {
                panier.Remove(produitARetirer);
            }
        }


        public void miseAJourQuantite(List<produit> panier, int idProduit, int nouvelleQuantite)
        {
            produit produitAModifier = panier.FirstOrDefault(p => p.id == idProduit);
            if (produitAModifier != null)
            {
                produitAModifier.quantite = nouvelleQuantite;
            }
        }


        public double calculPrixTotal()
        {

            return quantite * prix;
        }

        public double calculPrixTotalPanier(List<produit> panier)
        {

            double prixTotalPanier = 0;
            foreach (var item in panier)
            {
                prixTotalPanier += item.prix * item.quantite;
            }
            return prixTotalPanier;
        }

        public void viderPanier(List<produit> panier)
        {

            panier.Clear();
        }

        public void afficherPanier(List<produit> panier)
        {

            foreach (var item in panier)
            {
                string affiche = ($"ID: {item.id}, Nom: {item.nom}, Quantité: {item.quantite}, Prix unitaire: {item.prix}");
            }
        }
    }
}
