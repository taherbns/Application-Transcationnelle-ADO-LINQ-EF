﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace laboratoire1.Models
{
   
    public class Etudiant : DbContext
    {
        public string id { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public string niveauEduc { get; set; }
        public string courriel { get; set; }
        public string idLogin { get; set; }

    }
}